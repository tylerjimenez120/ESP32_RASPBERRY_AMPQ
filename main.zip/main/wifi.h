#pragma once

void wifi_init_sta(void);
