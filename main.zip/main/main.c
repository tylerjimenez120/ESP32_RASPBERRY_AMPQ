#include "nvs_flash.h"
#include "esp_event.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "mqtt_amqp.h"
#include "esp_log.h"
#include "wifi.h"

// Tarea para simular la lectura de un sensor
void sensor_publishing_task(void *pvParameters) {
    int counter = 0;
    while (1) {
        char payload[64];
        sprintf(payload, "{\"id\": \"ESP32_LAB\", \"valor\": %d}", counter++);
        
        // Usamos nuestra función modular
        mqtt_app_publish(TOPIC_SENSOR, payload);
        
        vTaskDelay(pdMS_TO_TICKS(5000)); // Esperar 5 segundos
    }
}

void app_main(void) {
    // 1. Inicialización básica de hardware
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    // 2. Conectar a WiFi (Debe estar implementado en tu proyecto)
    // ejemplo_conectar_wifi(); 
    wifi_init_sta();

    vTaskDelay(pdMS_TO_TICKS(5000));
    // 3. Iniciar el módulo de mensajería
    mqtt_app_start();

    // 4. Crear la tarea de FreeRTOS
    xTaskCreate(sensor_publishing_task, "sensor_task", 4096, NULL, 5, NULL);
}