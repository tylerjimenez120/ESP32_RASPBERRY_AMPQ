#ifndef MQTT_AMQP_H
#define MQTT_AMQP_H

#include "mqtt_client.h"
#include <stdbool.h>

#define BROKER_URL     "mqtt://192.168.100.52:1883"
#define TOPIC_SENSOR   "sensor/datos"

void mqtt_app_start(void);
void mqtt_app_publish(const char *topic, const char *data);
bool mqtt_is_connected(void);

#endif
