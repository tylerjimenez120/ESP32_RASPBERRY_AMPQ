#include <stdio.h>
#include <string.h>
#include "esp_log.h"
#include "mqtt_client.h"
#include "mqtt_amqp.h"

static const char *TAG = "MQTT_MODULE";

static esp_mqtt_client_handle_t client = NULL;
static bool mqtt_connected = false;

/* =========================
 * MQTT EVENT HANDLER
 * ========================= */
static void mqtt_event_handler(void *handler_args,
                               esp_event_base_t base,
                               int32_t event_id,
                               void *event_data)
{
    // Convertimos event_data para acceder a los datos de los mensajes
    esp_mqtt_event_handle_t event = (esp_mqtt_event_handle_t)event_data;

    switch ((esp_mqtt_event_id_t)event_id) {

        case MQTT_EVENT_CONNECTED:
            mqtt_connected = true;
            ESP_LOGI(TAG, "Conectado al Broker MQTT");
            // SUSCRIPCIÓN: Al conectar, escuchamos el tópico de comandos
            esp_mqtt_client_subscribe(client, "sensor/comandos", 0);
            ESP_LOGI(TAG, "Suscrito a tópico de comandos");
            break;

        case MQTT_EVENT_DISCONNECTED:
            mqtt_connected = false;
            ESP_LOGW(TAG, "Desconectado del Broker MQTT");
            break;

        case MQTT_EVENT_DATA:
            // NUEVO: Manejo de datos entrantes (Comandos desde Python)
            ESP_LOGI(TAG, "Comando recibido en tópico: %.*s", event->topic_len, event->topic);
            printf("Contenido del comando: %.*s\r\n", event->data_len, event->data);
            
            // Ejemplo de respuesta automática
            if (strncmp(event->data, "PING", event->data_len) == 0) {
                esp_mqtt_client_publish(client, "sensor/datos", "{\"status\":\"PONG\"}", 0, 1, 0);
            }
            break;

        case MQTT_EVENT_ERROR:
            mqtt_connected = false;
            ESP_LOGE(TAG, "Error en el evento MQTT");
            if (event->error_handle->error_type == MQTT_ERROR_TYPE_TCP_TRANSPORT) {
                ESP_LOGE(TAG, "Error de transporte TCP detectado");
            }
            break;

        default:
            break;
    }
}

/* =========================
 * START MQTT
 * ========================= */
void mqtt_app_start(void)
{
    if (client != NULL) {
        ESP_LOGW(TAG, "MQTT ya inicializado");
        return;
    }

    esp_mqtt_client_config_t mqtt_cfg = {
        .broker = {
            .address = {
                .uri = BROKER_URL,
            },
        },
        .network = {
            .timeout_ms = 15000,
        },
    };

    client = esp_mqtt_client_init(&mqtt_cfg);

    esp_mqtt_client_register_event(
        client,
        ESP_EVENT_ANY_ID,
        mqtt_event_handler,
        NULL
    );

    esp_mqtt_client_start(client);
}

/* =========================
 * PUBLISH
 * ========================= */
void mqtt_app_publish(const char *topic, const char *data)
{
    if (!client || !mqtt_connected) {
        ESP_LOGW(TAG, "MQTT no conectado, mensaje descartado");
        return;
    }

    int msg_id = esp_mqtt_client_publish(
        client,
        topic,
        data,
        0,
        1,
        0
    );

    if (msg_id >= 0) {
        ESP_LOGI(TAG, "Mensaje enviado (ID: %d): %s", msg_id, data);
    } else {
        ESP_LOGE(TAG, "Error al publicar mensaje");
    }
}

/* =========================
 * STATUS
 * ========================= */
bool mqtt_is_connected(void)
{
    return mqtt_connected;
}