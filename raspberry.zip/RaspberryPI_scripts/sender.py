
import pika
import sys

def enviar_comando():
    try:
        # Conexión al Broker
        connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
        channel = connection.channel()

        # Input del usuario
        comando = input("Escribe el comando (ej: LED_ON, LED_OFF, PING): ")

        # Publicar en el exchange amq.topic
        channel.basic_publish(
            exchange='amq.topic',
            routing_key='sensor/comandos',
            body=comando,
            properties=pika.BasicProperties(delivery_mode=2) # Mensaje persistente
        )

        print(f" [OK] Comando '{comando}' enviado correctamente.")
        connection.close()

    except pika.exceptions.AMQPConnectionError:
        print(" [ERROR] No se pudo conectar con RabbitMQ. ¿Está activo el contenedor?")
    except Exception as e:
        print(f" [ERROR] Ocurrió algo inesperado: {e}")

if __name__ == "__main__":
    enviar_comando()