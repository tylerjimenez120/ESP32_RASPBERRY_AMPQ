import pika
import sys

def main():
    # 1. Conexión
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    # 2. Una sola cola es suficiente para este script
    # Si quieres que el nombre sea genérico:
    queue_name = 'cola_sensores_unificada'
    channel.queue_declare(queue=queue_name, durable=True)
    
    # 3. Vincular al tópico (puedes usar '#' si quieres capturar todo)
    channel.queue_bind(exchange='amq.topic', queue=queue_name, routing_key='sensor.datos')

    print(' [*] Escuchando AMQP. Escribiendo en consola y en log_sensores.txt...')

    # 4. Callback mejorado
    def callback(ch, method, properties, body):
        mensaje = body.decode()
        
        # Acción 1: Consola
        print(f" [AMQP] Recibido: {mensaje}")
        
        # Acción 2: Archivo (con context manager para seguridad)
        try:
            with open("log_sensores.txt", "a") as f:
                f.write(f"{mensaje}\n")
        except Exception as e:
            print(f"Error escribiendo en archivo: {e}")

    # 5. Consumo
    channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=True)
    
    channel.start_consuming()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nSaliendo...')
        sys.exit(0)